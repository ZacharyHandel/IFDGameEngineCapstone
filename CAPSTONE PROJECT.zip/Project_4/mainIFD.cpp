/*
Name- Zachary Handel
Assignment- IFD Game Engine
Due Date- *There will be many changes to this program*
Description- This is the main driver for the IFD game engine created by Dr. Ray. Throughout this course, we will be making changes and adding
			 new features to learn new concepts of OOP.
*/
#include "Game.h"

using namespace std;

int main(){
	Game game;
	game.play();
	return 0;
}
