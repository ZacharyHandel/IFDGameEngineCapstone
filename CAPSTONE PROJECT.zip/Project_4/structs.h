struct Rule
{
        int beginRm;
        char direction;
        int destRm;
};

struct Effect
{
    int effectID;
    int effectAmt;
};